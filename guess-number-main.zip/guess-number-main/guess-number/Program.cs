﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace guess_number
{

    public class Program
    {
        static void Main()
        {
            Random rastgele = new Random();
            int hedefSayi = rastgele.Next(1, 101);
            int tahmin;
            int denemeSayisi = 0;
            Console.WriteLine("1 ile 100 arasında bir sayi ahmin etmeye çalış");

            do
            {
                Console.Write("Tahmininiz: ");
                tahmin = Convert.ToInt32(Console.ReadLine());
                denemeSayisi++;

                if (tahmin > hedefSayi)
                    Console.WriteLine("Daha küçük bir sayı girin.");
                else if (tahmin < hedefSayi)
                    Console.WriteLine("Daha büyük bir sayı girin.");
            }
            while (tahmin != hedefSayi);

            Console.WriteLine($"Tebrikler! {denemeSayisi} denemede doğru tahmini yaptınız.");
        }
    }

}
