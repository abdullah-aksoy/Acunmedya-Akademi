# BookStore - Online Kitap Mağazası  

**BookStore**, kullanıcıların kitapları arayabileceği, sepete ekleyebileceği ve sipariş oluşturabileceği bir ASP.NET Core MVC projesidir. Yöneticiler, kitapları ekleyebilir, düzenleyebilir ve silebilir.  

### 📌 **Öne Çıkan Özellikler**  
✅ **Kullanıcı İşlemleri** – Kayıt, giriş ve çıkış  
✅ **Kitap Arama** – Başlık veya yazara göre filtreleme  
✅ **Sepet Yönetimi** – Kitap ekleme/çıkarma ve sipariş tamamlama  
✅ **Sipariş Geçmişi** – Kullanıcıların geçmiş siparişlerini görüntülemesi  
✅ **Admin Paneli** – Kitap ekleme, düzenleme ve silme  

### 🛠 **Teknolojiler**  
- **Backend:** ASP.NET Core MVC  
- **Veritabanı:** Entity Framework Core (SQL Server)  
- **Kimlik Doğrulama:** ASP.NET Core Identity  
- **Frontend:** Bootstrap  
