using Microsoft.AspNetCore.Identity;

namespace BookStoreFull.Models
{
    public class ApplicationUser : IdentityUser
    {
        // additional profile fields can go here
    }
}
