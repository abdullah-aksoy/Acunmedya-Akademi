using Microsoft.AspNetCore.Mvc;
using BookStoreFull.Models;
using Microsoft.AspNetCore.Identity;
using BookStoreFull.ViewModels;

namespace BookStoreFull.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public AccountController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);
            var user = new ApplicationUser { UserName = model.UserName, Email = model.Email };
            var res = await _userManager.CreateAsync(user, model.Password);
            if (res.Succeeded)
            {
                await _signInManager.SignInAsync(user, isPersistent: false);
                return RedirectToAction("Index", "Home");
            }
            foreach (var e in res.Errors) ModelState.AddModelError(string.Empty, e.Description);
            return View(model);
        }

        public IActionResult Login(string? returnUrl) => View(new LoginViewModel { ReturnUrl = returnUrl });

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);
            var res = await _signInManager.PasswordSignInAsync(model.UserName, model.Password, model.RememberMe, false);
            if (res.Succeeded) return Redirect(model.ReturnUrl ?? "/");
            ModelState.AddModelError(string.Empty, "Invalid login."); 
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
    }
}
