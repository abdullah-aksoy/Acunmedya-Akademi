using Microsoft.AspNetCore.Mvc;
using BookStoreFull.Data;
using BookStoreFull.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStoreFull.Controllers
{
    public class CartController : Controller
    {
        private readonly AppDbContext _context;
        public CartController(AppDbContext context) { _context = context; }

        private const string SessionCartKey = "Cart";

        public async Task<IActionResult> Add(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();

            var cart = GetCart();
            var item = cart.FirstOrDefault(i => i.BookId == id);
            if (item == null)
            {
                cart.Add(new CartItemViewModel { BookId = id, Title = book.Title, UnitPrice = book.Price, Quantity = 1 });
            }
            else item.Quantity++;

            SaveCart(cart);
            return RedirectToAction("Index", "Cart");
        }

        public IActionResult Index()
        {
            var cart = GetCart();
            return View(cart);
        }

        public IActionResult Remove(int id)
        {
            var cart = GetCart();
            var item = cart.FirstOrDefault(i => i.BookId == id);
            if (item != null) { cart.Remove(item); SaveCart(cart); }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Checkout([FromServices] Microsoft.AspNetCore.Identity.UserManager<BookStoreFull.Models.ApplicationUser> userManager)
        {
            var cart = GetCart();
            if (!User.Identity!.IsAuthenticated) return RedirectToAction("Login", "Account");

            var user = await userManager.GetUserAsync(User);
            if (user == null) return Challenge();

            var order = new Order { UserId = user.Id, OrderDate = DateTime.UtcNow, Total = cart.Sum(i => i.LineTotal) };
            order.Items = cart.Select(i => new OrderItem { BookId = i.BookId, Quantity = i.Quantity, UnitPrice = i.UnitPrice }).ToList();
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            // clear session cart
            HttpContext.Session.Remove(SessionCartKey);
            return RedirectToAction("Details", "Orders", new { id = order.Id });
        }

        private List<CartItemViewModel> GetCart()
        {
            var json = HttpContext.Session.GetString(SessionCartKey);
            if (string.IsNullOrEmpty(json)) return new List<CartItemViewModel>();
            return System.Text.Json.JsonSerializer.Deserialize<List<CartItemViewModel>>(json)!;
        }
        private void SaveCart(List<CartItemViewModel> cart)
        {
            HttpContext.Session.SetString(SessionCartKey, System.Text.Json.JsonSerializer.Serialize(cart));
        }
    }
}
