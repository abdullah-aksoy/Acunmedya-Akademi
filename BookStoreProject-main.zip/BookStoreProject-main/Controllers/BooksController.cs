using Microsoft.AspNetCore.Mvc;
using BookStoreFull.Data;
using Microsoft.EntityFrameworkCore;
using BookStoreFull.Models;

namespace BookStoreFull.Controllers
{
    public class BooksController : Controller
    {
        private readonly AppDbContext _context;
        public BooksController(AppDbContext context) { _context = context; }

        public async Task<IActionResult> Index(string? search, int page = 1)
        {
            var qry = _context.Books.AsQueryable();
            if (!string.IsNullOrEmpty(search))
            {
                qry = qry.Where(b => b.Title!.Contains(search) || b.Author!.Contains(search));
            }
            var list = await qry.OrderBy(b => b.Title).ToListAsync();
            return View(list);
        }

        public async Task<IActionResult> Details(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();
            return View(book);
        }
    }
}
