using Microsoft.AspNetCore.Mvc;
using BookStoreFull.Data;
using Microsoft.EntityFrameworkCore;

namespace BookStoreFull.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;
        public HomeController(AppDbContext context) { _context = context; }

        public async Task<IActionResult> Index()
        {
            var books = await _context.Books.Take(6).ToListAsync();
            return View(books);
        }
    }
}
