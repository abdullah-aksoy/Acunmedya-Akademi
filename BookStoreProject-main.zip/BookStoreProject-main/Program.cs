using BookStoreFull.Data;
using BookStoreFull.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection") ?? "Data Source=bookstore_full.db"));

builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    options.Password.RequireDigit = true;
    options.Password.RequiredLength = 6;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireLowercase = false;
})
    .AddEntityFrameworkStores<AppDbContext>()
    .AddDefaultTokenProviders();

var app = builder.Build();

// Ensure database created and seed sample data + admin user
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var context = services.GetRequiredService<AppDbContext>();
    context.Database.EnsureCreated();

    // seed books
    if (!context.Books.Any())
    {
        context.Books.AddRange(
            new Book { Title = "The Pragmatic Programmer", Author = "Andrew Hunt", Price = 39.99M, Genre = "Programming" },
            new Book { Title = "Clean Code", Author = "Robert C. Martin", Price = 34.50M, Genre = "Programming" },
            new Book { Title = "Design Patterns", Author = "Erich Gamma", Price = 45.00M, Genre = "Software" }
        );
        context.SaveChanges();
    }

    // seed admin user
    var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
    var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
    string adminRole = "Admin";
    if (!roleManager.RoleExistsAsync(adminRole).Result)
    {
        roleManager.CreateAsync(new IdentityRole(adminRole)).Wait();
    }

    string adminEmail = "admin@bookstore.test";
    var adminUser = userManager.FindByEmailAsync(adminEmail).Result;
    if (adminUser == null)
    {
        adminUser = new ApplicationUser { UserName = "admin", Email = adminEmail, EmailConfirmed = true };
        var res = userManager.CreateAsync(adminUser, "Admin123!").Result;
        if (res.Succeeded)
        {
            userManager.AddToRoleAsync(adminUser, adminRole).Wait();
        }
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
