Access Specifiers
public: Her yerden erişilebilir (örneğin, herkesin görebileceği bir sokak lambası).
private: Sadece sınıf içinde erişilebilir (örneğin, bir kişinin banka hesabı).
protected: Sınıf ve türetilmiş sınıflardan erişilebilir (örneğin, aileye ait özel bilgiler).
internal: Aynı projede erişilebilir (örneğin, bir şirketin dahili yazılım).
Erişim belirleyiciler, encapsulation ile verileri dışarıdan korur ve sadece gerekli bilgilere erişim sağlar.
